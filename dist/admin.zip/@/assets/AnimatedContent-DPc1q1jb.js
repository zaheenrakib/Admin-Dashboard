import{j as e}from"./index-CJy4qUNt.js";const a=({children:t})=>e.jsx("div",{className:"tab tab-enter",children:t});export{a as A};
