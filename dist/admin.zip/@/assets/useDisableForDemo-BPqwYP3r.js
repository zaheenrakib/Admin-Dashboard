import"./index-CJy4qUNt.js";import"./toast-Cy6Kz85v.js";const s=()=>({handleDisableForDemo:()=>!1});export{s as u};
