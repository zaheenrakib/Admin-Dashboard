const s="/@/assets/spinner-BpCQcvP1.gif";export{s};
